#!/bin/bash

# Loop through all .xyz files in the current directory
for file in *.xyz; do
    echo "Processing file: $file"
    
    # Initialize a temporary file to hold atom counts
    temp_file=$(mktemp)
    
    # Extract atom types (the first column) starting from the 3rd row and count them
    tail -n +3 "$file" | awk '{print $1}' | sort | uniq -c | sort -nr > "$temp_file"
    
    # Check if the temp file has any content
    if [[ -s "$temp_file" ]]; then
        # Output the counts for each atom type
        echo "Atom counts for $file:"
        while read count atom; do
            echo "$atom$count"
        done < "$temp_file"
    else
        echo "No atoms found in $file."
    fi
    
    # Clean up the temporary file
    rm "$temp_file"
    
    echo "---"
done

