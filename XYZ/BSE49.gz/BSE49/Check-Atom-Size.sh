for file in *.xyz; do

    
    awk '
    BEGIN {
        C_count = 0
        O_count = 0
        N_count = 0
        H_count = 0
        F_count = 0
        Cl_count = 0
        B_count = 0
        Si_count = 0
        P_count = 0
        S_count = 0
        
    }

    {
        if ($1 == "C") {
            C_count++
        } else if ($1 == "O") {
            O_count++
        } else if ($1 == "N") {
            N_count++
        } else if ($1 == "H") {
            H_count++
        } else if ($1 == "Cl") {
        Cl_count++
        } else if ($1 == "F") {
        F_count++
        } else if ($1 == "P") {
        P_count++
        } else if ($1 == "S") {
        S_count++
        } else if ($1 == "Si") {
        Si_count++
        } else if ($1 == "B") {
        B_count++
        }
    }

    END {
        print FILENAME, C_count, O_count, N_count, H_count, F_count, Cl_count, Si_count, S_count, B_count, P_count
    }
    ' "$file"
    done
